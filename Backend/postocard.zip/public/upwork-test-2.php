<?php

declare(strict_types=1);

function my_max(
    array $xs
): int {
    $highest = 0;
    foreach ($xs as $data) {
        if (is_array($data)) {

            $data = my_max($data);
        }

        if ($data>$highest) {
            $highest = $data;
        }
    }
    return($highest);
}

echo my_max([1, [20000, [3,8, 99,[87,1,2],1000]]]); // 99
