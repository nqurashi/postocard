<?php

    #Reverse Function
   function my_rev($String)
   {
        #Reverse String Variable
        $Reverse = "";

        for ($i = strlen($String)-1; $i >= 0; $i--)
        {
            $Reverse .= $String[$i];
        }
        return $Reverse;
   }


   #String Variable
   $String = "abc";

   #Outputing the Result
   echo my_rev($String);
?>
